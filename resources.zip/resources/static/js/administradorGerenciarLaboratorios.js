// Variável global para armazenar a instância do modal
let labModalInstance;
// Recupera os laboratórios do localStorage ou inicializa com um array vazio
let laboratorios = JSON.parse(localStorage.getItem("laboratorios")) || [];

function carregarLaboratorios() {
    const container = document.getElementById("labContainer");
    container.innerHTML = "";
    laboratorios.forEach((lab, index) => {
        const col = document.createElement("div");
        col.className = "col-md-6 mb-4";
        col.innerHTML = `
                    <div class="card text-center">
                        <div class="card-body">
                            <h1>🔬</h1>
                            <h2 class="card-title">${lab.nome}</h2>
                            <div class="details">
                                <p>${lab.computadores} computadores</p>
                                <p>Ferramentas: ${lab.ferramentas.join(", ")}</p>
                                <p>Status: ${lab.ativo ? "Disponível" : "Inativo"}</p>
                            </div>
                            <div class="d-flex justify-content-center gap-2 flex-wrap">
                                <button class="btn btn-info" onclick="showLabModal(${index})">Editar</button>
                                <button class="btn ${lab.ativo ? 'btn-success' : 'btn-secondary'}" onclick="toggleLabStatus(${index})">${lab.ativo ? 'Inativar' : 'Ativar'}</button>
                                <button class="btn btn-danger" onclick="excluirLab(${index})">Excluir</button>
                            </div>
                        </div>
                    </div>
                `;
        container.appendChild(col);
    });
    localStorage.setItem("laboratorios", JSON.stringify(laboratorios));
}

function showLabModal(index) {
    labModalInstance = new bootstrap.Modal(document.getElementById("labModal"));
    if (index !== undefined) {
        document.getElementById("labModalLabel").innerText = "Editar Laboratório";
        document.getElementById("labName").value = laboratorios[index].nome;
        document.getElementById("labComputers").value = laboratorios[index].computadores;
        document.getElementById("labTools").value = laboratorios[index].ferramentas.join(", ");
        document.getElementById("labIndex").value = index;
    } else {
        document.getElementById("labModalLabel").innerText = "Adicionar Laboratório";
        document.getElementById("labForm").reset();
        document.getElementById("labIndex").value = "";
    }
    labModalInstance.show();
}

function saveLab() {
    const nome = document.getElementById("labName").value.trim();
    const computadores = parseInt(document.getElementById("labComputers").value);
    // Separa e filtra ferramentas vazias
    const ferramentas = document.getElementById("labTools").value
        .split(",")
        .map(f => f.trim())
        .filter(f => f);
    const index = document.getElementById("labIndex").value;
    if (!nome || isNaN(computadores) || computadores < 1 || ferramentas.length === 0) {
        alert("Preencha todos os campos corretamente!");
        return;
    }
    if (index === "") {
        laboratorios.push({ nome, computadores, ferramentas, ativo: true });
    } else {
        laboratorios[index] = { nome, computadores, ferramentas, ativo: laboratorios[index].ativo };
    }
    carregarLaboratorios();
    labModalInstance.hide();
}

// Alterna o status do laboratório entre disponível e inativo
function toggleLabStatus(index) {
    laboratorios[index].ativo = !laboratorios[index].ativo;
    carregarLaboratorios();
}

// Exclui o laboratório após confirmação do usuário
function excluirLab(index) {
    if (confirm("Deseja realmente excluir este laboratório?")) {
        laboratorios.splice(index, 1);
        carregarLaboratorios();
    }
}

document.addEventListener("DOMContentLoaded", carregarLaboratorios);
