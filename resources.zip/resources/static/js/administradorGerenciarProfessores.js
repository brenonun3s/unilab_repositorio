let users = JSON.parse(localStorage.getItem("professores")) || [];

// Gera uma senha aleatória com 10 caracteres
function generatePassword() {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@$!%*?&";
    let password = "";
    for (let i = 0; i < 10; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
}

// Atualiza a tabela com os dados dos professores e salva no localStorage
function updateTable() {
    const userTable = document.getElementById("userTable");
    let tableContent = "";
    users.forEach((user, index) => {
        tableContent += `
      <tr>
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td>
          <span id="password-${index}" class="password-hidden">**********</span>
          <button class="btn btn-secondary btn-sm" onclick="requestAdminPassword(${index})">🔑</button>
        </td>
        <td>${user.active ? "Ativo" : "Inativo"}</td>
        <td>
          <button class="btn btn-primary" onclick="editUser(${index})">Editar</button>
          <button class="btn btn-danger" onclick="deleteUser(${index})">Excluir</button>
          <button class="btn ${user.active ? 'btn-warning' : 'btn-success'}" onclick="toggleUserStatus(${index})">
            ${user.active ? "Inativar" : "Reativar"}
          </button>
        </td>
      </tr>
    `;
    });
    userTable.innerHTML = tableContent;
    localStorage.setItem("professores", JSON.stringify(users));
}

// Solicita a senha do administrador para revelar a senha do professor
function requestAdminPassword(index) {
    const adminPassword = prompt("Digite a senha do administrador para revelar a senha do professor:");
    if (adminPassword === "1234") {
        document.getElementById(`password-${index}`).textContent = users[index].password;
    } else {
        alert("Senha incorreta!");
    }
}

// Permite editar os dados do professor
function editUser(index) {
    let newName = prompt("Digite o novo nome do professor:", users[index].name);
    if (newName) {
        newName = newName.trim().toUpperCase();
        if (/\d/.test(newName)) {
            alert("O nome do professor não pode conter números!");
            return;
        }
        users[index].name = newName;
    }
    let newEmail = prompt("Digite o novo email institucional:", users[index].email);
    if (newEmail) {
        newEmail = newEmail.trim().toLowerCase();
        users[index].email = newEmail;
    }
    updateTable();
}

// Exclui o professor da lista
function deleteUser(index) {
    if (confirm("Tem certeza que deseja excluir este professor?")) {
        users.splice(index, 1);
        updateTable();
    }
}

// Alterna o status ativo/inativo do professor
function toggleUserStatus(index) {
    users[index].active = !users[index].active;
    updateTable();
}

// Adiciona um novo professor
function createUser() {
    const userName = document.getElementById("userName").value.trim().toUpperCase();
    const userEmail = document.getElementById("userEmail").value.trim().toLowerCase();
    const userPassword = generatePassword();

    if (!userName || !userEmail) {
        alert("Por favor, preencha todos os campos!");
        return;
    }

    if (/\d/.test(userName)) {
        alert("O nome do professor não pode conter números!");
        return;
    }

    users.push({ name: userName, email: userEmail, password: userPassword, active: true });
    updateTable();
    document.getElementById("userForm").reset();

    setTimeout(() => {
        if (confirm("Professor adicionado com sucesso!")) {
            document.getElementById("userName").focus();
        }
    }, 200);
}

document.addEventListener("DOMContentLoaded", updateTable);