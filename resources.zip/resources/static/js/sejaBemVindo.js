function openConfigModal() {
    const configModal = new bootstrap.Modal(document.getElementById('configModal'));
    configModal.show();
}

// Adiciona suporte para teclado: ativa o clique quando Enter ou Espaço for pressionado.
document.querySelectorAll('.card[role="button"]').forEach(function(card) {
    card.addEventListener('keydown', function(event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            card.click();
        }
    });
});