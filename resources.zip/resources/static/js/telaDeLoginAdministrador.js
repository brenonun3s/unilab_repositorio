document.addEventListener('DOMContentLoaded', function() {
    // Elementos do formulário
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const rememberCheckbox = document.getElementById('rememberMe');
    const passwordToggle = document.querySelector('.password-toggle');
    const feedbackDiv = document.getElementById('feedback');

    // Função para mostrar feedback
    function showFeedback(message, type = 'success') {
        feedbackDiv.className = `alert alert-${type} alert-dismissible fade show`;
        feedbackDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        feedbackDiv.style.display = 'block';
    }

    // Toggle de visibilidade da senha
    if (passwordToggle) {
        passwordToggle.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.querySelector('i').classList.toggle('bi-eye');
            this.querySelector('i').classList.toggle('bi-eye-slash');
        });
    }

    // Validação do formulário
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Remove feedback anterior
        feedbackDiv.style.display = 'none';
        
        // Validação básica
        if (!usernameInput.value || !passwordInput.value) {
            showFeedback('Por favor, preencha todos os campos.', 'danger');
            return;
        }

        // Simula autenticação
        handleLogin(usernameInput.value, passwordInput.value);
    });

    // Função de login
    function handleLogin(username, password) {
        // Credenciais corretas
        const correctUsername = 'rafael';
        const correctPassword = '123456';

        // Simula delay de autenticação
        const submitButton = loginForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Entrando...';

        setTimeout(() => {
            if (username === correctUsername && password === correctPassword) {
                // Salva usuário se "Lembrar-me" estiver marcado
                if (rememberCheckbox.checked) {
                    localStorage.setItem('rememberedUser', username);
                } else {
                    localStorage.removeItem('rememberedUser');
                }

                showFeedback('Login realizado com sucesso! Redirecionando...', 'success');
                
                // Redireciona para a página de boas-vindas
                setTimeout(() => {
                    window.location.href = 'sejaBemVindo.html';
                }, 1000);
            } else {
                showFeedback('Usuário ou senha incorretos.', 'danger');
                submitButton.disabled = false;
                submitButton.innerHTML = 'Entrar';
            }
        }, 1000);
    }

    // Verifica se há usuário salvo
    const rememberedUser = localStorage.getItem('rememberedUser');
    if (rememberedUser) {
        usernameInput.value = rememberedUser;
        rememberCheckbox.checked = true;
    }

    // Previne envio do formulário ao pressionar Enter
    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                loginForm.dispatchEvent(new Event('submit'));
            }
        });
    });
}); 