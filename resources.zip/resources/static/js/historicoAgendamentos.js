function formatarData(data) {
    const [ano, mes, dia] = data.split("-");
    return `${dia}/${mes}/${ano}`;
}
function carregarHistorico() {
    const historico = JSON.parse(localStorage.getItem("historicoAgendamentos")) || [];
    const historyTable = document.getElementById("historyTable");
    const noRecords = document.getElementById("noRecords");
    historyTable.innerHTML = "";
    if (historico.length === 0) {
        noRecords.style.display = "block";
    } else {
        noRecords.style.display = "none";
        historico.forEach(item => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
          <td>${item.laboratorio || "Não informado"}</td>
          <td>${item.professor}</td>
          <td>${formatarData(item.data)}</td>
          <td>${item.horario}</td>
        `;
            historyTable.appendChild(tr);
        });
    }
}
function filtrarHistorico() {
    const filterText = document.getElementById("filterInput").value.toLowerCase();
    const rows = document.querySelectorAll("#historyTable tr");
    rows.forEach(row => {
        const professor = row.children[1].textContent.toLowerCase();
        row.style.display = professor.includes(filterText) ? "" : "none";
    });
}
document.getElementById("filterInput").addEventListener("keyup", filtrarHistorico);
document.addEventListener("DOMContentLoaded", carregarHistorico);