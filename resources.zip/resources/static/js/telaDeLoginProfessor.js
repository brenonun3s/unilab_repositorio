// Senha fixa definida (idealmente movida para backend)
const senhaFixa = "1234";

document.getElementById("entrar").onclick = function () {
    const login = document.getElementById("login").value;
    const senha = document.getElementById("senha").value;

    if (login && senha) {
        // Validação do login e senha: login deve ser "professor" e senha "1234"
        if (login.toLowerCase() === "professor" && senha === senhaFixa) {
            alert('Login bem-sucedido! Bem-vindo, professor.');
            window.location.href = "sejaBemVindo.html";
        } else {
            alert('Login ou senha incorretos!');
        }
    } else {
        alert('Por favor, preencha todos os campos!');
    }
};