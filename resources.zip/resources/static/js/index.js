document.addEventListener("DOMContentLoaded", function () {
    const chatResponses = {
        "Como posso redefinir minha senha?":
            "Para redefinir sua senha, clique em 'Esqueceu sua senha?' na tela de login e siga as instruções repassadas pelos administradores.",
        "Como faço para acessar como Administrador?":
            "Clique no botão 'Administrador' para ser redirecionado à página de login do Administrador, digite login e senha para acessar as funcionalidades do sistema.",
        "Como posso acessar como Professor?":
            "Clique no botão 'Professor' para ser redirecionado à página de login do Professor.",
        "Quais são os canais de suporte disponíveis?":
            "Você pode contatar o suporte via email: suporte@unilab.com ou pelo telefone: (XX) XXXXX-XXXX.",
        "Qual é o horário de atendimento?":
            "Nosso atendimento funciona de segunda a sexta, das 8h às 18h.",
        "Como atualizar meus dados cadastrais?":
            "Para atualizar seus dados, acesse sua conta e vá até a seção de configurações do perfil.",
        "Como acesso meu histórico de agendamento?":
            "Você pode acessar seu histórico de horarios agendados na aba de Historico de Agendamentos, busque pelo seu nome para filtrar os resultados.",
        "Quais horários estão indisponíveis?": obterHorariosIndisponiveis,
    };

    const chatIcon = document.getElementById("chatBotIcon");
    const chatPanel = document.getElementById("chatPanel");
    let feedbackTimeoutId;
    let feedbackDisabled = false;

    function clearChatHistory() {
        const chatBody = document.querySelector(".chat-body");
        chatBody.innerHTML = "";
    }

    function addMessage(message, sender = "user") {
        const chatBody = document.querySelector(".chat-body");
        const messageDiv = document.createElement("div");
        messageDiv.className = `chat-message ${
            sender === "user" ? "message-sent" : "message-received"
        }`;
        messageDiv.textContent = message;
        chatBody.appendChild(messageDiv);
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    function addFeedbackMessage() {
        const chatBody = document.querySelector(".chat-body");
        const feedbackDiv = document.createElement("div");
        feedbackDiv.className = "chat-message message-received";

        const questionText = document.createElement("div");
        questionText.textContent = "Consegui ajudar?";

        const buttonContainer = document.createElement("div");
        buttonContainer.style.marginTop = "5px";

        const simButton = document.createElement("button");
        simButton.textContent = "Sim";
        simButton.style.marginRight = "5px";
        simButton.style.backgroundColor = "#007bff";
        simButton.style.border = "none";
        simButton.style.color = "#fff";
        simButton.style.padding = "5px 10px";
        simButton.style.borderRadius = "4px";
        simButton.style.cursor = "pointer";
        simButton.style.transition = "background-color 0.2s";

        const naoButton = document.createElement("button");
        naoButton.textContent = "Não";
        naoButton.style.backgroundColor = "#dc3545";
        naoButton.style.border = "none";
        naoButton.style.color = "#fff";
        naoButton.style.padding = "5px 10px";
        naoButton.style.borderRadius = "4px";
        naoButton.style.cursor = "pointer";
        naoButton.style.transition = "background-color 0.2s";

        buttonContainer.appendChild(simButton);
        buttonContainer.appendChild(naoButton);

        feedbackDiv.appendChild(questionText);
        feedbackDiv.appendChild(buttonContainer);
        chatBody.appendChild(feedbackDiv);
        chatBody.scrollTop = chatBody.scrollHeight;

        simButton.addEventListener("click", function () {
            feedbackDiv.remove();
            askForRating();
        });

        naoButton.addEventListener("click", function () {
            feedbackDisabled = true;
            feedbackDiv.remove();
            addMessage(
                "Sinto muito que não tenha conseguido a ajuda. Para suporte, entre em contato pelo email: suporte@unilab.com ou pelo telefone: (XX) XXXXX-XXXX.",
                "bot"
            );
            setTimeout(toggleChat, 5000);
        });
    }

    function askForRating() {
        const chatBody = document.querySelector(".chat-body");
        const ratingDiv = document.createElement("div");
        ratingDiv.className = "chat-message message-received";

        const promptText = document.createElement("div");
        promptText.textContent = "Por favor, avalie o atendimento de 0 a 5:";

        const ratingContainer = document.createElement("div");
        ratingContainer.style.marginTop = "5px";

        for (let i = 0; i <= 5; i++) {
            const ratingButton = document.createElement("button");
            ratingButton.textContent = i;
            ratingButton.style.marginRight = "5px";
            ratingButton.style.backgroundColor = "#007bff";
            ratingButton.style.border = "none";
            ratingButton.style.color = "#fff";
            ratingButton.style.padding = "5px 10px";
            ratingButton.style.borderRadius = "4px";
            ratingButton.style.cursor = "pointer";
            ratingButton.style.transition = "background-color 0.2s";

            ratingButton.addEventListener("click", function () {
                addMessage("Obrigado pela avaliação!", "bot");
                setTimeout(toggleChat, 1000);
            });

            ratingContainer.appendChild(ratingButton);
        }

        ratingDiv.appendChild(promptText);
        ratingDiv.appendChild(ratingContainer);
        chatBody.appendChild(ratingDiv);
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    function finishSupport() {
        addFeedbackMessage();
    }

    function toggleChat() {
        chatPanel.classList.toggle("visible");
        if (!chatPanel.classList.contains("visible")) {
            if (feedbackTimeoutId) clearTimeout(feedbackTimeoutId);
            setTimeout(() => {
                clearChatHistory();
                feedbackDisabled = false;
            }, 300);
        } else {
            if (document.querySelector(".chat-body").innerHTML.trim() === "") {
                addMessage("Olá! Como posso ajudar?", "bot");
            }
        }
    }

    // Função para obter horários indisponíveis integrando com o sistema de agendamento
    function obterHorariosIndisponiveis() {
        function formatarDataLocal(data) {
            const [ano, mes, dia] = data.split("-");
            return `${dia}/${mes}/${ano}`;
        }
        let labs = JSON.parse(localStorage.getItem("laboratorios")) || [];
        let message = "";
        labs.forEach((lab, index) => {
            let agendamentos =
                JSON.parse(localStorage.getItem(`lab${index}_agendamentos`)) ||
                [];
            if (agendamentos.length > 0) {
                message += `No laboratório ${lab.nome}: `;
                agendamentos.forEach((ag) => {
                    message += `dia ${formatarDataLocal(ag.data)} (${ag.horario
                        }); `;
                });
                message += "\n";
            }
        });
        return message || "Nenhum horário indisponível registrado.";
    }

    chatIcon.addEventListener("click", toggleChat);

    document.querySelectorAll(".quick-btn").forEach((button) => {
        button.addEventListener("click", function () {
            const message = this.getAttribute("data-msg");
            addMessage(message, "user");

            setTimeout(() => {
                const response =
                    typeof chatResponses[message] === "function"
                        ? chatResponses[message]()
                        : chatResponses[message];
                addMessage(response, "bot");

                if (!feedbackDisabled) {
                    feedbackTimeoutId = setTimeout(addFeedbackMessage, 1000);
                }
            }, 500);
        });
    });

    document
        .getElementById("finalizarAtendimento")
        .addEventListener("click", finishSupport);
});